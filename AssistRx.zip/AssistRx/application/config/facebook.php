<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['appId']  = '518363434893715';
$config['secret'] = '98552bfeac69d429f27b4dd393266829';



?>