<div class="col-lg-3 col-xs-6">
    <!-- small box -->
    <div class="small-box bg-aqua">
        <div class="inner">
            <h3>
                Patients
            </h3>

        </div>
        <div class="icon">
            <i class="ion ion-person-add"></i>
        </div>
        <a href="/patients" class="small-box-footer">
            View Patients <i class="fa fa-arrow-circle-right"></i>
        </a>
    </div>
</div><!-- ./col -->
<div class="col-lg-3 col-xs-6">
    <!-- small box -->
    <div class="small-box bg-green">
        <div class="inner">
            <h3>
                Reports
            </h3>

        </div>
        <div class="icon">
            <i class="ion ion-stats-bars"></i>
        </div>
        <a href="/reports" class="small-box-footer">
            View Reports <i class="fa fa-arrow-circle-right"></i>
        </a>
    </div>
</div><!-- ./col -->
